$(document).ready(function() {
	AOS.init({
	  duration: 1200
});